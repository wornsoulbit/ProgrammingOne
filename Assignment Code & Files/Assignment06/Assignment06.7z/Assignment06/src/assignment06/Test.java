package assignment06;

/**
 *
 * @author Alex Vasil
 */
public class Test {
    
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        System.out.println(r1);
    }
    
}
